// Tokens
`define PID_OUT                    8'hE1
`define PID_IN                     8'h69
`define PID_SOF                    8'hA5
`define PID_SETUP                  8'hD2  // 2D

// Data
`define PID_DATA0                  8'hC3
`define PID_DATA1                  8'h4B
`define PID_DATA2                  8'h87
`define PID_MDATA                  8'h0F

// Handshake
`define PID_ACK                    8'hD2
`define PID_NAK                    8'h5A
`define PID_STALL                  8'h1E
`define PID_NYET                   8'h96

// Special
`define PID_PRE                    8'h3C
`define PID_ERR                    8'h3C
`define PID_SPLIT                  8'h78
`define PID_PING                   8'hB4

`define USB_PID_W      8
`define USB_DEV_W      7
`define USB_EP_W       4

module link_rx(
  input         clk,
  input         rst_n,
  
  // register interface
  input [ 7:0]  self_addr,          //done
  //input         ms,
  //input [15:0]  time_threshold,
  //input [ 5:0]  delay_threshold,
  
  //output        crc5_err,
  output        crc16_err,
  //output        time_out,
  //output        d_oe,

  //PHY interface
  input         rx_lp_sop,
  input         rx_lp_eop,
  input         rx_lp_valid,        //done 
  input [ 7:0]  rx_lp_data,         //done

  output  reg   rx_lp_ready,

  //Transaction interface
  input         rx_lt_ready,
  output        rx_pid_en,
  output  [3:0] rx_pid,             //done
  output  [3:0] rx_endp,
  output        rx_lt_sop,
  output        rx_lt_eop,
  output        rx_lt_valid,
  output  [7:0] rx_lt_data
);


localparam STATE_RX_IDLE                 = 4'd0;
localparam STATE_RX_TOKEN2               = 4'd1;
localparam STATE_RX_TOKEN3               = 4'd2;
localparam STATE_RX_TOKEN_COMPLETE       = 4'd3;
localparam STATE_RX_SOF2                 = 4'd4;
localparam STATE_RX_SOF3                 = 4'd5;
localparam STATE_RX_DATA                 = 4'd6;
localparam STATE_RX_DATA_COMPLETE        = 4'd7;
localparam STATE_RX_IGNORED              = 4'd8;


reg [`USB_DEV_W-1:0]        token_dev_q;
reg [`USB_EP_W-1:0]         token_ep_q;
reg [`USB_PID_W-1:0]        token_pid_q;


// hand shake with phy
// TBD rx_lp_ready always 1 for now
always @ (posedge clk or negedge rst_n) begin
  if(!rst_n) 
    rx_lp_ready <= 1'b1;
  else if(rx_lp_valid && rx_lp_sop && (!rx_lp_ready))
    rx_lp_ready <= 1'b1;
end

reg [31:0] data_buffer_q;
reg        rx_lp_valid_dly;

always @ (posedge clk or negedge rst_n)
  if (!rst_n)begin
    data_buffer_q <= 32'b0;
    rx_lp_valid_dly <= 1'b0;
  end
  else if (rx_lp_valid && rx_lp_ready)begin
    data_buffer_q <= {rx_lp_data, data_buffer_q[31:8]};
    rx_lp_valid_dly <= rx_lp_valid;
  end
  else begin
    rx_lp_valid_dly <= 1'b0;
    data_buffer_q <= data_buffer_q;
  end

wire [7:0] data_w = data_buffer_q[31:24];

reg rx_lp_eop_dly;

/*
always @ (posedge clk or negedge rst_n) begin
  if(!rst_n) 
    rx_lp_eop_dly <= 1'b0;
  else if(rx_lp_valid && rx_lp_eop)
    rx_lp_eop_dly <= rx_lp_eop;
	else if(rx_lp_sop)
    rx_lp_eop_dly <= 1'b0;
end
*/

always @ (posedge clk or negedge rst_n) begin
  if(!rst_n) 
    rx_lp_eop_dly <= 1'b0;
  else 
    rx_lp_eop_dly <= rx_lp_eop;
end


// crc recived flag
reg [1:0] data_crc_q;
always @ (posedge clk or negedge rst_n)
if (!rst_n)
    data_crc_q <= 2'b0;
else if (rx_lp_valid && rx_lp_ready)
    data_crc_q <= {rx_lp_eop, data_crc_q[1]};

wire crc_byte_w = data_crc_q[0]; // crc byte received flag


reg [3:0] c_state, n_state;

always @(posedge clk or negedge rst_n) begin
  if(~rst_n) 
    c_state <= STATE_RX_IDLE;
  else
    c_state <= n_state;
end

reg rx_lp_sop_dly;

always @(posedge clk or negedge rst_n) begin
  if(!rst_n) 
    rx_lp_sop_dly <= 1'b0;
  else if(rx_lp_sop && rx_lp_valid)
    rx_lp_sop_dly <= rx_lp_sop;
  else
    rx_lp_sop_dly <= 1'b0;
end


always @ *
begin
    n_state = c_state;
    case (c_state)
    //-----------------------------------------
    // IDLE
    //-----------------------------------------
    STATE_RX_IDLE :
    begin
       if (rx_lp_sop_dly)
       begin
           // Decode PID
           case (data_w)

              `PID_OUT, `PID_IN, `PID_SETUP, `PID_PING:
                    n_state  = STATE_RX_TOKEN2;

              `PID_SOF:
                    n_state  = STATE_RX_SOF2;

              `PID_DATA0, `PID_DATA1, `PID_DATA2, `PID_MDATA:
              begin
                    n_state  = STATE_RX_DATA;
              end

              `PID_ACK, `PID_NAK, `PID_STALL, `PID_NYET:
                    n_state  = STATE_RX_IDLE;

              default : // SPLIT / ERR
                    n_state  = STATE_RX_IGNORED;
           endcase
       end
    end

    //-----------------------------------------
    // RX_IGNORED: Unknown / unsupported 这个地方可以改成超时或者CRC错误
    //-----------------------------------------
    STATE_RX_IGNORED :
    begin
        // Wait until the end of the packet
        if (rx_lp_eop_dly)
           n_state = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // SOF (BYTE 2)
    //-----------------------------------------
    STATE_RX_SOF2 :
    begin
       if (rx_lp_valid_dly)
           n_state = STATE_RX_SOF3;
       else if (rx_lp_eop_dly)
           n_state = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // SOF (BYTE 3)
    //-----------------------------------------
    STATE_RX_SOF3 :
    begin
       if ( rx_lp_valid_dly || rx_lp_eop_dly)
           n_state = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // TOKEN (IN/OUT/SETUP) (Address/Endpoint)
    //-----------------------------------------
    STATE_RX_TOKEN2 :
    begin
       if (rx_lp_valid_dly)
           n_state = STATE_RX_TOKEN3;
       else if (rx_lp_eop_dly)
           n_state = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // TOKEN (IN/OUT/SETUP) (Endpoint/CRC)
    //-----------------------------------------
    STATE_RX_TOKEN3 :
    begin
       if (rx_lp_valid_dly)
           n_state = STATE_RX_TOKEN_COMPLETE;
       else if (rx_lp_eop_dly)
           n_state = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // RX_TOKEN_COMPLETE
    //-----------------------------------------
    STATE_RX_TOKEN_COMPLETE :
    begin
        n_state  = STATE_RX_IDLE;
    end

    //-----------------------------------------
    // RX_DATA
    //-----------------------------------------
    STATE_RX_DATA :
    begin
       // Receive complete
       if (crc_byte_w)
            n_state = STATE_RX_DATA_COMPLETE;
    end

    //-----------------------------------------
    // RX_DATA_COMPLETE
    //-----------------------------------------
    STATE_RX_DATA_COMPLETE :
    begin
        if (rx_lp_eop_dly)
            n_state = STATE_RX_IDLE;
    end

    default :
       ;

    endcase
end

//-----------------------------------------------------------------
// Token: PID
//-----------------------------------------------------------------
always @ (posedge clk or negedge rst_n)
if (!rst_n)
    token_pid_q <= `USB_PID_W'b0;
else if (c_state == STATE_RX_IDLE && rx_lp_valid_dly)
    token_pid_q <= data_w;
//else //if (!enable_i)
//    token_pid_q <= `USB_PID_W'b0;

assign rx_pid = token_pid_q[3:0];

reg token_valid_q;

wire       address_match_w = (token_dev_q == self_addr[6:0]);

always @ (posedge clk or negedge rst_n)
if (!rst_n)
    token_valid_q <= 1'b0;
else
    token_valid_q <= (c_state == STATE_RX_TOKEN_COMPLETE) && address_match_w;

assign rx_pid_en = token_valid_q || (c_state == STATE_RX_TOKEN2 && rx_lp_eop);



//-----------------------------------------------------------------
// Token: Device Address
//-----------------------------------------------------------------
always @ (posedge clk or negedge rst_n)
if (!rst_n)
    token_dev_q <= `USB_DEV_W'b0;
else if (c_state == STATE_RX_TOKEN2 && rx_lp_valid_dly)
    token_dev_q <= data_w[6:0];
//else //if (!enable_i)
//    token_dev_q <= `USB_DEV_W'b0;

assign token_addr_o = token_dev_q;

//-----------------------------------------------------------------
// Token: Endpoint
//-----------------------------------------------------------------
always @ (posedge clk or negedge rst_n)
if (!rst_n)
    token_ep_q      <= `USB_EP_W'b0;
else if (c_state == STATE_RX_TOKEN2 && rx_lp_valid_dly)
    token_ep_q[0]   <= data_w[7];
else if (c_state == STATE_RX_TOKEN3 && rx_lp_valid_dly)
    token_ep_q[3:1] <= data_w[2:0];
else //if (!enable_i)
    token_ep_q      <= `USB_EP_W'b0;

assign rx_endp = token_ep_q;
assign token_crc_err_o = 1'b0;

wire [7:0] input_data_w  = data_w;
wire       input_ready_w = c_state == STATE_RX_DATA && rx_lp_valid && !crc_byte_w;

//-----------------------------------------------------------------
// CRC5: Generate CRC5 on incoming data bytes
//-----------------------------------------------------------------
reg [4:0]  crc5_sum_q;
wire [4:0] crc5_out_w;
reg         crc5_err_q;

usbf_crc5
u_crc5
(
    .crc_in(crc5_sum_q),
    .din(data_w),
    .crc_out(crc5_out_w)
);

always @ (posedge clk or negedge rst_n)
if (!rst_n)
    crc5_sum_q   <= 5'h1F;
else if (c_state == STATE_RX_IDLE)
    crc5_sum_q   <= 5'h1F;
else if (rx_lp_valid)
    crc5_sum_q   <= crc5_out_w;

always @ (posedge clk or negedge rst_n)
if (!rst_n)
    crc5_err_q   <= 1'b0;
else if (c_state == STATE_RX_IDLE)
    crc5_err_q   <= 1'b0;
else if (c_state == STATE_RX_TOKEN_COMPLETE && n_state == STATE_RX_IDLE)
    crc5_err_q   <= (crc5_sum_q != 5'h00C);

assign crc5_err = crc5_err_q;



//-----------------------------------------------------------------
// CRC16: Generate CRC16 on incoming data bytes
//-----------------------------------------------------------------
reg [15:0]  crc_sum_q;
wire [15:0] crc_out_w;
reg         crc_err_q;

usbf_crc16
u_crc16
(
    .crc_in_i(crc_sum_q),
    .din_i(data_w),
    .crc_out_o(crc_out_w)
);

always @ (posedge clk or negedge rst_n)
if (!rst_n)
    crc_sum_q   <= 16'hFFFF;
else if (c_state == STATE_RX_IDLE)
    crc_sum_q   <= 16'hFFFF;
else if (rx_lp_valid)
    crc_sum_q   <= crc_out_w;

always @ (posedge clk or negedge rst_n)
if (!rst_n)
    crc_err_q   <= 1'b0;
else if (c_state == STATE_RX_IDLE)
    crc_err_q   <= 1'b0;
else if (c_state == STATE_RX_DATA_COMPLETE && n_state == STATE_RX_IDLE)
    crc_err_q   <= (crc_sum_q != 16'hB001);

assign crc16_err = crc_err_q;





endmodule
