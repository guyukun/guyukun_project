//1. As Device
//   When received IN token, link_tx send data to

`define PID_OUT                    8'hE1
`define PID_IN                     8'h69
`define PID_SOF                    8'hA5
`define PID_SETUP                  8'h2D

// Data
`define PID_DATA0                  8'hC3
`define PID_DATA1                  8'h4B
`define PID_DATA2                  8'h87
`define PID_MDATA                  8'h0F

// Handshake
`define PID_ACK                    8'hD2
`define PID_NAK                    8'h5A
`define PID_STALL                  8'h1E
`define PID_NYET                   8'h96

// Special
`define PID_PRE                    8'h3C
`define PID_ERR                    8'h3C
`define PID_SPLIT                  8'h78
`define PID_PING                   8'hB4

module link_tx(
  input clk,                        //done 
  input rst_n,                      //done
  
  // register interface
  input [ 7:0]  self_addr,          //done
  input         ms,
  input [15:0]  time_threshold,
  input [ 5:0]  delay_threshold,
  
  output        crc5_err,
  output        crc16_err,
  output        time_out,
  output        d_oe,

  //PHY interface
  input         tx_lp_ready,        //done
  output	reg		tx_lp_sop,
  output	reg		tx_lp_eop,
  output        tx_lp_valid,        //done
  output  [7:0] tx_lp_data,         //done
  output        tx_lp_cancle,       

  //Transaction interface
  input [3:0]   tx_pid,             //done
  input [6:0]   tx_addr,
  input [3:0]   tx_endp,
  input         tx_valid,
  input         tx_lt_sop,
  input         tx_lt_eop,
  input         tx_lt_valid,
  input [7:0]   tx_lt_data, 
  input         tx_lt_cancle,

  output        tx_ready,
  output        tx_lt_ready
);


localparam STATE_TX_IDLE                 = 3'd0;
localparam STATE_TX_PID                  = 3'd1;
localparam STATE_TX_DATA                 = 3'd2;
localparam STATE_TX_CRC1                 = 3'd3;
localparam STATE_TX_CRC2                 = 3'd4;
localparam STATE_TX_DONE                 = 3'd5;


reg [2:0] c_state, n_state;

//-----------------------------------------------------------------
// Request Type
//-----------------------------------------------------------------
reg data_pid_q;
//reg data_zlp_q;

always @ (posedge clk or negedge rst_n)
if (!rst_n)
begin
    data_pid_q <= 1'b0;
    //data_zlp_q <= 1'b0;
end
//else if (!enable_i)
//begin
//    data_pid_q <= 1'b0;
    //data_zlp_q <= 1'b0;
//end
else if (tx_lt_valid)
begin
    case (tx_pid)

    `PID_MDATA, `PID_DATA2, `PID_DATA0, `PID_DATA1:
    begin
        data_pid_q <= 1'b1;
        //data_zlp_q <= data_valid_i && (data_strb_i == 1'b0) && data_last_i;
    end

    default :
    begin
        data_pid_q <= 1'b0;
        //data_zlp_q <= 1'b0;
    end
    endcase
end
else if (n_state == STATE_TX_CRC1)
begin
    data_pid_q <= 1'b0;
    //data_zlp_q <= 1'b0;
end

assign tx_accept_o = (c_state == STATE_TX_IDLE);





always @ (posedge clk or negedge rst_n)
  if(!rst_n)
    c_state <= STATE_TX_IDLE;
  else
    c_state <= n_state;
  
//-----------------------------------------------------------------
// Next state
//-----------------------------------------------------------------
always @ *
begin
    //-----------------------------------------
    // State Machine
    //-----------------------------------------
    case (c_state)

    //-----------------------------------------
    // IDLE
    //-----------------------------------------
    STATE_TX_IDLE :
    begin
        //if (chirp_i)
        //    n_state  = STATE_TX_CHIRP;
       if (tx_lt_sop && ms == 1'b1)
            n_state  = STATE_TX_PID;
       else if(tx_lt_sop && ms == 1'b0)
            n_state  = STATE_TX_DATA;
    end

    //-----------------------------------------
    // TX_PID
    //-----------------------------------------
    STATE_TX_PID :
    begin
        // Data accepted
        if (tx_lp_ready)
        begin
            //if (data_zlp_q)
            //    n_state = STATE_TX_CRC1;
            //else if (data_pid_q)
            if (data_pid_q)
                n_state = STATE_TX_DATA;
            else
                n_state = STATE_TX_DONE;
        end
    end

    //-----------------------------------------
    // TX_DATA
    //-----------------------------------------
    STATE_TX_DATA :
    begin
        // Data accepted
        if (tx_lp_ready)
        begin
            // Generate CRC16 at end of packet
            //if (data_last_i)
            //    n_state  = STATE_TX_CRC1;
            if (tx_lp_eop)
                n_state  = STATE_TX_DONE;
        end
    end
    /*
    //-----------------------------------------
    // TX_CRC1 (first byte)
    //-----------------------------------------
    STATE_TX_CRC1 :
    begin
        // Data sent?
        if (utmi_txready_i)
            n_state  = STATE_TX_CRC2;
    end

    //-----------------------------------------
    // TX_CRC (second byte)
    //-----------------------------------------
    STATE_TX_CRC2 :
    begin
        // Data sent?
        if (utmi_txready_i)
            n_state  = STATE_TX_DONE;
    end
    */
    //-----------------------------------------
    // TX_DONE
    //-----------------------------------------
    STATE_TX_DONE :
    begin
        if (!tx_lp_valid || tx_lp_ready)
            n_state  = STATE_TX_IDLE;
    end
    /*
    //-----------------------------------------
    // TX_CHIRP
    //-----------------------------------------
    STATE_TX_CHIRP :
    begin
        if (!chirp_i)
            n_state  = STATE_TX_IDLE;
    end
    */
    default : n_state = STATE_TX_IDLE;
       

    endcase

  
end


//-----------------------------------------------------------------
// Output
//-----------------------------------------------------------------


reg [7:0] data_buffer;

assign tx_lt_ready = (n_state == STATE_TX_DATA || n_state == STATE_TX_DONE) && tx_lp_ready;

always @ (posedge clk or negedge rst_n)
	if (!rst_n)
		data_buffer <= 8'd0;
	else if( (n_state == STATE_TX_DATA || n_state == STATE_TX_DONE) && tx_lt_ready && tx_lt_valid)
		data_buffer <= tx_lt_data ;


reg       valid_q;
reg [7:0] data_q;

always @ (posedge clk or negedge rst_n)
if (!rst_n)
begin
    valid_q <= 1'b0;
    data_q  <= 8'b0;
end
//else if (!enable_i)
//begin
//    valid_q <= 1'b0;
//    data_q  <= 8'b0;
//end
else if (tx_lp_valid)
begin
    valid_q <= 1'b1;
    data_q  <= tx_pid;
end
else if (tx_lp_ready)
begin
    valid_q <= 1'b0;
    data_q  <= 8'b0;
end

reg       utmi_txvalid_r;
reg [7:0] utmi_data_r;

always @ (posedge clk or negedge rst_n)begin
    //if (c_state == STATE_TX_CHIRP)
    //begin
    //    utmi_txvalid_r = 1'b1;
    //    utmi_data_r    = 8'b0;
    //end
    /*
    if (c_state == STATE_TX_CRC1)
    begin
        utmi_txvalid_r = 1'b1;
        utmi_data_r    = crc_sum_q[7:0] ^ 8'hFF;
    end
    else if (c_state == STATE_TX_CRC2)
    begin
        utmi_txvalid_r = 1'b1;
        utmi_data_r    = crc_sum_q[15:8] ^ 8'hFF;
    end
    */
    if(!rst_n)begin
    	//utmi_txvalid_r = 1'b0;
      utmi_data_r    = 8'd0;
    end
    else if(n_state == STATE_TX_DATA || n_state == STATE_TX_DONE)begin
    	//utmi_txvalid_r = 1'b1;
      utmi_data_r    = data_buffer;
    end
    else if (n_state == STATE_TX_PID)begin
      //utmi_txvalid_r = valid_q;
      utmi_data_r    = data_q;
    end
end


always @ (posedge clk or negedge rst_n)begin
    //if (c_state == STATE_TX_CHIRP)
    //begin
    //    utmi_txvalid_r = 1'b1;
    //    utmi_data_r    = 8'b0;
    //end
    /*
    if (c_state == STATE_TX_CRC1)
    begin
        utmi_txvalid_r = 1'b1;
        utmi_data_r    = crc_sum_q[7:0] ^ 8'hFF;
    end
    else if (c_state == STATE_TX_CRC2)
    begin
        utmi_txvalid_r = 1'b1;
        utmi_data_r    = crc_sum_q[15:8] ^ 8'hFF;
    end
    */

    if(!rst_n)begin
    	utmi_txvalid_r = 1'b0;
    end
    else if(n_state == STATE_TX_DATA )begin
    	utmi_txvalid_r = 1'b1; 
    end
    else if (n_state == STATE_TX_PID)begin
      utmi_txvalid_r = valid_q;
    end
    else
    	utmi_txvalid_r = 1'b0;
end


assign tx_lp_valid = utmi_txvalid_r;
assign tx_lp_data    = utmi_data_r;

always @ (posedge clk or negedge rst_n)begin
	if(!rst_n)
		tx_lp_sop <= 1'b0;
	else if(tx_lt_ready)
		tx_lp_sop <= tx_lt_sop;
end

always @ (posedge clk or negedge rst_n)begin
	if(!rst_n)
		tx_lp_eop <= 1'b0;
	else if(tx_lt_ready)
		tx_lp_eop <= tx_lt_eop;
end
		
assign d_oe = (c_state == STATE_TX_DATA || c_state == STATE_TX_DONE);


endmodule
