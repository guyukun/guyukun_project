module usb_link_top(
  input clk,                        //done 
  input rst_n,                      //done
  
  // register interface
  input [ 7:0]  self_addr,          //Half Done
  input         ms,                 //TODO
  input [15:0]  time_threshold,     //TODO
  input [ 5:0]  delay_threshold,    //TODO
  
  output        crc5_err,           //TX TODO RX Done
  output        crc16_err,          //RX Done
  output        time_out,           //TODO
  output        d_oe,               //Half Done
  
  //PHY interface
  input         rx_lp_sop,
  input         rx_lp_eop,
  input         rx_lp_valid,        //done 
  input [ 7:0]  rx_lp_data,         //done
  input         tx_lp_ready,        //done
  
  output        rx_lp_ready,
  output        tx_lp_sop,
  output        tx_lp_eop,
  output        tx_lp_valid,        //done
  output  [7:0] tx_lp_data,         //done
  output        tx_lp_cancle,       
  
  //Transaction interface
  input         rx_lt_ready,
  input [3:0]   tx_pid,             //done
  input [6:0]   tx_addr,
  input [3:0]   tx_endp,
  input         tx_valid,
  input         tx_lt_sop,
  input         tx_lt_eop,
  input         tx_lt_valid,
  input [7:0]   tx_lt_data, 
  input         tx_lt_cancle,
  
  output        rx_pid_en,
  output  [3:0] rx_pid,             //done
  output  [3:0] rx_endp,
  output        rx_lt_sop,
  output        rx_lt_eop,
  output        rx_lt_valid,
  output  [7:0] rx_lt_data,
  output        tx_ready,
  output        tx_lt_ready
  
);


link_tx u_link_tx(
  .clk              (clk),                        
  .rst_n            (rst_n),                      
  
  //register interface
  .self_addr        (self_addr),          
  .ms               (ms),
  .time_threshold   (time_threshold),
  .delay_threshold  (delay_threshold),
  
  .crc5_err         (crc5_err),
  .crc16_err        (crc16_err),
  .time_out         (time_out),
  .d_oe             (d_oe),

  //PHY interface
  .tx_lp_ready      (tx_lp_ready),        
  .tx_lp_sop        (tx_lp_sop),
  .tx_lp_eop        (tx_lp_eop),
  .tx_lp_valid      (tx_lp_valid),        
  .tx_lp_data       (tx_lp_data),         
  .tx_lp_cancle     (tx_lp_cancle),       

  //Transaction interface
  .tx_pid           (tx_pid),             
  .tx_addr          (tx_addr),
  .tx_endp          (tx_endp),
  .tx_valid         (tx_valid),
  .tx_lt_sop        (tx_lt_sop),
  .tx_lt_eop        (tx_lt_eop),
  .tx_lt_valid      (tx_lt_valid),
  .tx_lt_data       (tx_lt_data), 
  .tx_lt_cancle     (tx_lt_cancle),

  .tx_ready         (tx_ready),
  .tx_lt_ready      (tx_lt_ready)
);

link_rx u_link_rx(
  .clk(clk),
  .rst_n(rst_n),
  
  // register interface
  .self_addr(self_addr),          //done
  //.ms(ms),
  //.time_threshold(time_threshold),
  //.delay_threshold(delay_threshold),
  
  //.crc5_err(crc5_err),
  .crc16_err(crc16_err),
  //.time_out(time_out),
  //.d_oe(d_oe),

  //PHY interface
  .rx_lp_sop(rx_lp_sop),
  .rx_lp_eop(rx_lp_eop),
  .rx_lp_valid(rx_lp_valid),        //done 
  .rx_lp_data(rx_lp_data),         //done

  .rx_lp_ready(rx_lp_ready),

  //Transaction interface
  .rx_lt_ready(rx_lt_ready),
  .rx_pid_en(rx_pid_en),
  .rx_pid(rx_pid),             //done
  .rx_endp(rx_endp),
  .rx_lt_sop(rx_lt_sop),
  .rx_lt_eop(rx_lt_eop),
  .rx_lt_valid(rx_lt_valid),
  .rx_lt_data(rx_lt_data)
);

// undo list

assign crc5_err = 1'b0;
assign time_out = 1'b0;
assign rx_lt_sop = 1'b0;
assign rx_lt_eop = 1'b0;
assign rx_lt_valid = 1'b0;
assign tx_lt_cancle = 1'b0;
assign tx_lp_cancle = 1'b0;
assign rx_lt_data = 8'd0;
assign tx_ready = 1'b1;

endmodule
