`timescale 1 ps/ 1 ps
module crc5_t_tb();
reg rst_n;
reg [6:0] tx_addr;
reg [3:0] tx_endp;
reg [3:0] tx_pid;
reg tx_to_ready;
reg tx_valid;
wire [3:0] tx_con_pid;
wire tx_con_pid_en;
wire tx_ready;
wire [7:0] tx_to_data;
wire tx_to_eop;
wire tx_to_sop;
wire tx_to_valid;
reg clk;
always #(10000) clk = ~clk;
initial clk = 0;

crc5_t u_crc5_t(
 .clk(clk),
 .rst_n(rst_n),
 .tx_addr(tx_addr),
 .tx_endp(tx_endp),
 .tx_pid(tx_pid),
 .tx_to_ready(tx_to_ready),
 .tx_valid(tx_valid),
 .tx_con_pid(tx_con_pid),
 .tx_con_pid_en(tx_con_pid_en),
 .tx_ready(tx_ready),
 .tx_to_data(tx_to_data),
 .tx_to_eop(tx_to_eop),
 .tx_to_sop(tx_to_sop),
 .tx_to_valid(tx_to_valid)

);

initial begin
 #(0) rst_n<=32'b0;
 #(92000) rst_n<=32'b1;
end

initial begin
 #(0) tx_addr<=32'b0000000;
end

initial begin
 #(0) tx_endp<=32'b0000;
end

initial begin
 #(0) tx_pid<=32'b0000;
end

initial begin
 #(0) tx_to_ready<=32'b1;
 #(1430000) tx_to_ready<=32'b0;
 #(5980000) tx_to_ready<=32'b1;
end

initial begin
 #(0) tx_valid<=32'b0;
end
initial 
begin            
    $dumpfile("crc5_t_tb.vcd");        //生成的vcd文件名称
    $dumpvars(0, crc5_t_tb);    //tb模块名称，根据自己的情况修改
end     
initial 
begin            
    #(30000000) $finish;
end   

endmodule
