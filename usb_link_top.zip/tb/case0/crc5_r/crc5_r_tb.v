`timescale 1 ps/ 1 ps
module crc5_r_tb();
reg rst_n;
reg rx_handshake_on;
reg [7:0] rx_lp_data;
reg rx_lp_eop;
reg rx_lp_sop;
reg rx_lp_valid;
reg rx_ready;
reg [6:0] self_addr;
wire crc5_err;
wire [7:0] rx_data;
wire [3:0] rx_endp;
wire rx_eop;
wire rx_lp_ready;
wire [3:0] rx_pid;
wire rx_pid_en;
wire rx_sop;
wire rx_valid;
reg clk;
always #(10000) clk = ~clk;
initial clk = 0;

crc5_r u_crc5_r(
 .clk(clk),
 .rst_n(rst_n),
 .rx_handshake_on(rx_handshake_on),
 .rx_lp_data(rx_lp_data),
 .rx_lp_eop(rx_lp_eop),
 .rx_lp_sop(rx_lp_sop),
 .rx_lp_valid(rx_lp_valid),
 .rx_ready(rx_ready),
 .self_addr(self_addr),
 .crc5_err(crc5_err),
 .rx_data(rx_data),
 .rx_endp(rx_endp),
 .rx_eop(rx_eop),
 .rx_lp_ready(rx_lp_ready),
 .rx_pid(rx_pid),
 .rx_pid_en(rx_pid_en),
 .rx_sop(rx_sop),
 .rx_valid(rx_valid)

);

initial begin
 #(0) rst_n<=32'b0;
 #(92000) rst_n<=32'b1;
end

initial begin
 #(0) rx_handshake_on<=32'b0;
 #(7410000) rx_handshake_on<=32'b1;
 #(1680000) rx_handshake_on<=32'b0;
end

initial begin
 #(0) rx_lp_data<=32'b00000000;
 #(111000) rx_lp_data<=32'b01101001;
 #(640000) rx_lp_data<=32'b00001000;
 #(640000) rx_lp_data<=32'b01011000;
 #(7639000) rx_lp_data<=32'b00000000;
 #(21000) rx_lp_data<=32'b11010010;
end

initial begin
 #(0) rx_lp_eop<=32'b0;
 #(1391000) rx_lp_eop<=32'b1;
 #(7639000) rx_lp_eop<=32'b0;
 #(21000) rx_lp_eop<=32'b1;
end

initial begin
 #(0) rx_lp_sop<=32'b0;
 #(111000) rx_lp_sop<=32'b1;
 #(640000) rx_lp_sop<=32'b0;
 #(8300000) rx_lp_sop<=32'b1;
end

initial begin
 #(0) rx_lp_valid<=32'b0;
 #(111000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(620000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(620000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(7640000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
end

initial begin
 #(0) rx_ready<=32'bz;
end

initial begin
 #(0) self_addr<=32'b0001000;
end
initial 
begin            
    $dumpfile("crc5_r_tb.vcd");        //生成的vcd文件名称
    $dumpvars(0, crc5_r_tb);    //tb模块名称，根据自己的情况修改
end     
initial 
begin            
    #(30000000) $finish;
end   

endmodule
