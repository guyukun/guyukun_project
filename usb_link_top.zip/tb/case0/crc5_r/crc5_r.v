module crc5_r(
 input clk,
 input rst_n,
 input rx_handshake_on,
 input [7:0] rx_lp_data,
 input rx_lp_eop,
 input rx_lp_sop,
 input rx_lp_valid,
 input rx_ready,
 input [6:0] self_addr,
 output crc5_err,
 output [7:0] rx_data,
 output [3:0] rx_endp,
 output rx_eop,
 output rx_lp_ready,
 output [3:0] rx_pid,
 output rx_pid_en,
 output rx_sop,
 output rx_valid
);
 wire addr_match;
 wire crc5_right;
 wire [4:0] c_out;
 wire [10:0] d;
 wire pid_h_l_ok;
 wire pid_is_not_data;
 reg addr_ok;
 reg pid_ok;


endmodule
