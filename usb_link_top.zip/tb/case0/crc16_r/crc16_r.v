module crc16_r(
 input clk,
 input rst_n,
 input [7:0] rx_data,
 input rx_data_on,
 input rx_eop,
 input rx_lt_ready,
 input rx_sop,
 input rx_valid,
 output [7:0] rx_lt_data,
 output rx_lt_eop,
 output rx_lt_eop_en,
 output rx_lt_sop,
 output rx_lt_valid,
 output rx_ready,
 output rx_sop_en
);
 wire packet_is_data;
 wire tran_buf;
 reg [7:0] data_reg;
 reg eop_reg;
 reg sop_reg;
 reg tran_en;
 reg valid_reg;


endmodule
