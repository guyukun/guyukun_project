`timescale 1 ps/ 1 ps
module control_t_tb();
reg rst_n;
reg tx_data_on;
reg tx_lp_ready;
reg tx_lt_cancle;
reg [7:0] tx_lt_data;
reg tx_lt_eop;
reg tx_lt_sop;
reg tx_lt_valid;
reg [7:0] tx_to_data;
reg tx_to_eop;
reg tx_to_sop;
reg tx_to_valid;
wire tx_lp_cancle;
wire [7:0] tx_lp_data;
wire tx_lp_eop;
wire tx_lp_eop_en;
wire tx_lp_sop;
wire tx_lp_valid;
wire tx_lt_ready;
wire tx_to_ready;
reg clk;
always #(10000) clk = ~clk;
initial clk = 0;

control_t u_control_t(
 .clk(clk),
 .rst_n(rst_n),
 .tx_data_on(tx_data_on),
 .tx_lp_ready(tx_lp_ready),
 .tx_lt_cancle(tx_lt_cancle),
 .tx_lt_data(tx_lt_data),
 .tx_lt_eop(tx_lt_eop),
 .tx_lt_sop(tx_lt_sop),
 .tx_lt_valid(tx_lt_valid),
 .tx_to_data(tx_to_data),
 .tx_to_eop(tx_to_eop),
 .tx_to_sop(tx_to_sop),
 .tx_to_valid(tx_to_valid),
 .tx_lp_cancle(tx_lp_cancle),
 .tx_lp_data(tx_lp_data),
 .tx_lp_eop(tx_lp_eop),
 .tx_lp_eop_en(tx_lp_eop_en),
 .tx_lp_sop(tx_lp_sop),
 .tx_lp_valid(tx_lp_valid),
 .tx_lt_ready(tx_lt_ready),
 .tx_to_ready(tx_to_ready)

);

initial begin
 #(0) rst_n<=32'b0;
 #(92000) rst_n<=32'b1;
end

initial begin
 #(0) tx_data_on<=32'b0;
 #(1430000) tx_data_on<=32'b1;
 #(5980000) tx_data_on<=32'b0;
end

initial begin
 #(0) tx_lp_ready<=32'b1;
 #(1470000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
end

initial begin
 #(0) tx_lt_cancle<=32'b0;
end

initial begin
 #(0) tx_lt_data<=32'b00000000;
 #(1431000) tx_lt_data<=32'b11000011;
 #(20000) tx_lt_data<=32'b00000001;
 #(20000) tx_lt_data<=32'b00000010;
 #(660000) tx_lt_data<=32'b00000011;
 #(660000) tx_lt_data<=32'b00000100;
 #(660000) tx_lt_data<=32'b00000101;
 #(660000) tx_lt_data<=32'b00000110;
 #(660000) tx_lt_data<=32'b00000111;
 #(660000) tx_lt_data<=32'b00001000;
 #(660000) tx_lt_data<=32'b00001001;
end

initial begin
 #(0) tx_lt_eop<=32'b0;
 #(6091000) tx_lt_eop<=32'b1;
end

initial begin
 #(0) tx_lt_sop<=32'b0;
 #(1431000) tx_lt_sop<=32'b1;
 #(20000) tx_lt_sop<=32'b0;
end

initial begin
 #(0) tx_lt_valid<=32'b0;
 #(1431000) tx_lt_valid<=32'b1;
 #(5320000) tx_lt_valid<=32'b0;
end

initial begin
 #(0) tx_to_data<=32'b11110000;
end

initial begin
 #(0) tx_to_eop<=32'b0;
end

initial begin
 #(0) tx_to_sop<=32'b1;
end

initial begin
 #(0) tx_to_valid<=32'b0;
end


initial begin
  $fsdbDumpfile("TEST_CASE.fsdb") ;
  $fsdbDumpvars() ;
  $fsdbDumpMDA();
end


     
initial 
begin            
    #(30000000) $finish;
end   

endmodule
