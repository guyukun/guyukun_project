`timescale 1 ps/ 1 ps
module link_control_tb();
reg [5:0] delay_threshole;
reg ms;
reg rst_n;
reg rx_lt_eop_en;
reg [3:0] rx_pid;
reg rx_pid_en;
reg rx_sop_en;
reg [15:0] time_threshold;
reg [3:0] tx_con_pid;
reg tx_con_pid_en;
reg tx_lp_eop_en;
wire d_oe;
wire rx_data_on;
wire rx_handshake_on;
wire time_out;
wire tx_data_on;
reg clk;
always #(10000) clk = ~clk;
initial clk = 0;

link_control u_link_control(
 .clk(clk),
 .delay_threshole(delay_threshole),
 .ms(ms),
 .rst_n(rst_n),
 .rx_lt_eop_en(rx_lt_eop_en),
 .rx_pid(rx_pid),
 .rx_pid_en(rx_pid_en),
 .rx_sop_en(rx_sop_en),
 .time_threshold(time_threshold),
 .tx_con_pid(tx_con_pid),
 .tx_con_pid_en(tx_con_pid_en),
 .tx_lp_eop_en(tx_lp_eop_en),
 .d_oe(d_oe),
 .rx_data_on(rx_data_on),
 .rx_handshake_on(rx_handshake_on),
 .time_out(time_out),
 .tx_data_on(tx_data_on)

);

initial begin
 #(0) delay_threshole<=32'b111111;
end

initial begin
 #(0) ms<=32'b0;
end

initial begin
 #(0) rst_n<=32'b0;
 #(92000) rst_n<=32'b1;
end

initial begin
 #(0) rx_lt_eop_en<=32'b0;
end

initial begin
 #(0) rx_pid<=32'b0000;
 #(130000) rx_pid<=32'b1001;
 #(8940000) rx_pid<=32'b0010;
end

initial begin
 #(0) rx_pid_en<=32'b0;
 #(1410000) rx_pid_en<=32'b1;
 #(20000) rx_pid_en<=32'b0;
 #(7640000) rx_pid_en<=32'b1;
 #(20000) rx_pid_en<=32'b0;
end

initial begin
 #(0) rx_sop_en<=32'b0;
end

initial begin
 #(0) time_threshold<=32'b0000000011001000;
end

initial begin
 #(0) tx_con_pid<=32'b0000;
end

initial begin
 #(0) tx_con_pid_en<=32'b0;
end

initial begin
 #(0) tx_lp_eop_en<=32'b0;
 #(7390000) tx_lp_eop_en<=32'b1;
 #(20000) tx_lp_eop_en<=32'b0;
end
initial 
begin            
    $dumpfile("link_control_tb.vcd");        //生成的vcd文件名称
    $dumpvars(0, link_control_tb);    //tb模块名称，根据自己的情况修改
end     
initial 
begin            
    #(30000000) $finish;
end   

endmodule
