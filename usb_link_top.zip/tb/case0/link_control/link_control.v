module link_control(
 input clk,
 input [5:0] delay_threshole,
 input ms,
 input rst_n,
 input rx_lt_eop_en,
 input [3:0] rx_pid,
 input rx_pid_en,
 input rx_sop_en,
 input [15:0] time_threshold,
 input [3:0] tx_con_pid,
 input tx_con_pid_en,
 input tx_lp_eop_en,
 output d_oe,
 output rx_data_on,
 output rx_handshake_on,
 output time_out,
 output tx_data_on
);
 wire delay_done;
 wire master_send_rt;
 wire master_send_wt;
 wire ms_receive_hs;
 wire slave_receive_rt;
 wire slave_receive_wt;
 reg [5:0] delay_cnt;
 reg delay_on;
 reg master_d_oe;
 reg master_finish_sending_rt;
 reg [1:0] master_finish_sending_wr;
 reg rx_sop_en_regd;
 reg slave_d_oe;
 reg slave_has_received_rt;
 reg [15:0] timer;


endmodule
