module usb_link_top(
 input clk,
 input [5:0] delay_threshole,
 input ms,
 input rst_n,
 input [7:0] rx_lp_data,
 input rx_lp_eop,
 input rx_lp_sop,
 input rx_lp_valid,
 input rx_lt_ready,
 input [6:0] self_addr,
 input [15:0] time_threshold,
 input [6:0] tx_addr,
 input [3:0] tx_endp,
 input tx_lp_ready,
 input tx_lt_cancle,
 input [7:0] tx_lt_data,
 input tx_lt_eop,
 input tx_lt_sop,
 input tx_lt_valid,
 input [3:0] tx_pid,
 input tx_valid,
 output crc5_err,
 output d_oe,
 output [3:0] rx_endp,
 output rx_lp_ready,
 output [7:0] rx_lt_data,
 output rx_lt_eop,
 output rx_lt_sop,
 output rx_lt_valid,
 output [3:0] rx_pid,
 output rx_pid_en,
 output time_out,
 output tx_lp_cancle,
 output [7:0] tx_lp_data,
 output tx_lp_eop,
 output tx_lp_sop,
 output tx_lp_valid,
 output tx_lt_ready,
 output tx_ready
);
 wire [7:0] rx_data;
 wire rx_data_on;
 wire rx_eop;
 wire rx_handshake_on;
 wire rx_lt_eop_en;
 wire rx_ready;
 wire rx_sop;
 wire rx_sop_en;
 wire rx_valid;
 wire [3:0] tx_con_pid;
 wire tx_con_pid_en;
 wire tx_data_on;
 wire tx_lp_eop_en;
 wire [7:0] tx_to_data;
 wire tx_to_eop;
 wire tx_to_ready;
 wire tx_to_sop;
 wire tx_to_valid;


endmodule
