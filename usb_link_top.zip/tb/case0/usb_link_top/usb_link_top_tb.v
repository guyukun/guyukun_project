`timescale 1 ps/ 1 ps
module usb_link_top_tb();
reg [5:0] delay_threshole;
reg ms;
reg rst_n;
reg [7:0] rx_lp_data;
reg rx_lp_eop;
reg rx_lp_sop;
reg rx_lp_valid;
reg rx_lt_ready;
reg [6:0] self_addr;
reg [15:0] time_threshold;
reg [6:0] tx_addr;
reg [3:0] tx_endp;
reg tx_lp_ready;
reg tx_lt_cancle;
reg [7:0] tx_lt_data;
reg tx_lt_eop;
reg tx_lt_sop;
reg tx_lt_valid;
reg [3:0] tx_pid;
reg tx_valid;
wire crc5_err;
wire d_oe;
wire [3:0] rx_endp;
wire rx_lp_ready;
wire [7:0] rx_lt_data;
wire rx_lt_eop;
wire rx_lt_sop;
wire rx_lt_valid;
wire [3:0] rx_pid;
wire rx_pid_en;
wire time_out;
wire tx_lp_cancle;
wire [7:0] tx_lp_data;
wire tx_lp_eop;
wire tx_lp_sop;
wire tx_lp_valid;
wire tx_lt_ready;
wire tx_ready;
reg clk;
always #(10000) clk = ~clk;
initial clk = 0;









usb_link_top u_usb_link_top(
 .clk(clk),
 .delay_threshold(delay_threshole),
 .ms(ms),
 .rst_n(rst_n),
 .rx_lp_data(rx_lp_data),
 .rx_lp_eop(rx_lp_eop),
 .rx_lp_sop(rx_lp_sop),
 .rx_lp_valid(rx_lp_valid),
 .rx_lt_ready(rx_lt_ready),
 .self_addr(self_addr),
 .time_threshold(time_threshold),
 .tx_addr(tx_addr),
 .tx_endp(tx_endp),
 .tx_lp_ready(tx_lp_ready),
 .tx_lt_cancle(tx_lt_cancle),
 .tx_lt_data(tx_lt_data),
 .tx_lt_eop(tx_lt_eop),
 .tx_lt_sop(tx_lt_sop),
 .tx_lt_valid(tx_lt_valid),
 .tx_pid(tx_pid),
 .tx_valid(tx_valid),
 .crc5_err(crc5_err),
 .d_oe(d_oe),
 .rx_endp(rx_endp),
 .rx_lp_ready(rx_lp_ready),
 .rx_lt_data(rx_lt_data),
 .rx_lt_eop(rx_lt_eop),
 .rx_lt_sop(rx_lt_sop),
 .rx_lt_valid(rx_lt_valid),
 .rx_pid(rx_pid),
 .rx_pid_en(rx_pid_en),
 .time_out(time_out),
 .tx_lp_cancle(tx_lp_cancle),
 .tx_lp_data(tx_lp_data),
 .tx_lp_eop(tx_lp_eop),
 .tx_lp_sop(tx_lp_sop),
 .tx_lp_valid(tx_lp_valid),
 .tx_lt_ready(tx_lt_ready),
 .tx_ready(tx_ready)

);



initial begin
 #(0) delay_threshole<=32'b111111;
end

initial begin
 #(0) ms<=32'b0;
end

initial begin
 #(0) rst_n<=32'b0;
 #(92000) rst_n<=32'b1;
end

initial begin
 #(0) rx_lp_data<=32'b00000000;
 #(111000) rx_lp_data<=32'b01101001;
 #(640000) rx_lp_data<=32'b00001000;
 #(640000) rx_lp_data<=32'b01011000;
 #(7639000) rx_lp_data<=32'b00000000;
 #(21000) rx_lp_data<=32'b11010010;
end

initial begin
 #(0) rx_lp_eop<=32'b0;
 #(1391000) rx_lp_eop<=32'b1;
 #(7639000) rx_lp_eop<=32'b0;
 #(21000) rx_lp_eop<=32'b1;
end

initial begin
 #(0) rx_lp_sop<=32'b0;
 #(111000) rx_lp_sop<=32'b1;
 #(640000) rx_lp_sop<=32'b0;
 #(8300000) rx_lp_sop<=32'b1;
end

initial begin
 #(0) rx_lp_valid<=32'b0;
 #(111000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(620000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(620000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
 #(7640000) rx_lp_valid<=32'b1;
 #(20000) rx_lp_valid<=32'b0;
end

initial begin
 #(0) rx_lt_ready<=32'b1;
end

initial begin
 #(0) self_addr<=32'b0001000;
end

initial begin
 #(0) time_threshold<=32'b0000000011001000;
end

initial begin
 #(0) tx_addr<=32'b0000000;
end

initial begin
 #(0) tx_endp<=32'b0000;
end

initial begin
 #(0) tx_lp_ready<=32'b1;
 #(1470000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
 #(20000) tx_lp_ready<=32'b0;
 #(640000) tx_lp_ready<=32'b1;
end

initial begin
 #(0) tx_lt_cancle<=32'b0;
end

initial begin
 #(0) tx_lt_data<=32'b00000000;
 #(1431000) tx_lt_data<=32'b11000011;
 #(20000) tx_lt_data<=32'b00000001;
 #(20000) tx_lt_data<=32'b00000010;
 #(660000) tx_lt_data<=32'b00000011;
 #(660000) tx_lt_data<=32'b00000100;
 #(660000) tx_lt_data<=32'b00000101;
 #(660000) tx_lt_data<=32'b00000110;
 #(660000) tx_lt_data<=32'b00000111;
 #(660000) tx_lt_data<=32'b00001000;
 #(660000) tx_lt_data<=32'b00001001;
end

initial begin
 #(0) tx_lt_eop<=32'b0;
 #(6091000) tx_lt_eop<=32'b1;
end

initial begin
 #(0) tx_lt_sop<=32'b0;
 #(1431000) tx_lt_sop<=32'b1;
 #(20000) tx_lt_sop<=32'b0;
end

initial begin
 #(0) tx_lt_valid<=32'b0;
 #(1431000) tx_lt_valid<=32'b1;
 #(5320000) tx_lt_valid<=32'b0;
end

initial begin
 #(0) tx_pid<=32'b0000;
end

initial begin
 #(0) tx_valid<=32'b0;
end

initial begin
  $fsdbDumpfile("TEST_CASE.fsdb") ;
  $fsdbDumpvars() ;
  $fsdbDumpMDA();
end   

initial 
begin            
    #(30000000) $finish;
end   

endmodule
