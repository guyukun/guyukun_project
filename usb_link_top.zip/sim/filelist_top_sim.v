



../../../usb_link_top/rtl/link_tx.v
../../../usb_link_top/rtl/link_rx.v
../../../usb_link_top/rtl/usbf_crc16.v
../../../usb_link_top/rtl/usbf_crc5.v

../../../usb_link_top/rtl/usb_link_top.v

../../../usb_link_top/tb/case0/usb_link_top/usb_link_top_tb.v

//../../../USB_chy/tb/case1/control_t/control_t_tb.v

//../../../USB_chy/tb/case2/control_t/control_t_tb.v

//../../../USB_chy/tb/case3/control_t/control_t_tb.v

